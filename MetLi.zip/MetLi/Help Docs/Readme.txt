Hello,

To read the documentation, Please open the index.html file in a Web Browser (eg: Chrome, Mozilla, Internet Explorer etc..)

Thanks a lot.

~Radwan